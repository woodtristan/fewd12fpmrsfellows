 $(document).ready(function(){
 	$('.carousel').slick();
 });
/*PAGE 2

submit form upon click of submit button

PAGE 3 

pull in calendar API 

create a pop-up box with event details when someone clicks an event in the calendar